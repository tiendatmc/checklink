Drunken Parrot Flat UI Free
=======

Drunken Parrot Flat UI Free is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/) and MIT License - http://opensource.org/licenses/mit-license.html.

## Links:

+ [Hoarrd.com](https://hoarrd.com/drunken-parrot-flat-ui-kit/)
+ [Components & Style Guide: Free Version](http://hoarrd.github.io/drunken-parrot-flat-ui/)