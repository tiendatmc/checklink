<?php

for ($i=0; $i < 3; $i++) { 
	
ini_set('max_execution_time', 300);

$url = array('http://tr.mobaloo.com/?offer_id=787574&pub_id=5767', 'http://trck.vamosmedia.com/index.php?offer_id=30496&aff_id=4307', 'http://tr.mobaloo.com/?offer_id=1117830&pub_id=5767');
$device = array('android','iphone', 'iphone');
$country = array('us','kr', 'kr');


$field2['url'] = $url[$i];
$field2['device'] = $device[$i];
$field2['country'] = $country[$i];


$datafield2 = http_build_query($field2);
$ch2 = curl_init();
curl_setopt($ch2, CURLOPT_COOKIEFILE, 'cookie.txt');
curl_setopt($ch2, CURLOPT_COOKIEJAR, 'cookie.txt');
curl_setopt($ch2, CURLOPT_URL, 'https://affilitest.com/validate');
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch2, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
//curl_setopt($ch2, CURLOPT_TIMEOUT, 60);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch2, CURLOPT_POST, 1);
curl_setopt($ch2, CURLOPT_POSTFIELDS, $datafield2.'&device=android');

$output = curl_exec($ch2);

$array = json_decode($output, true);

echo "<pre>";
var_dump($array['data']) ;
echo "</pre>";

curl_close($ch2);
}