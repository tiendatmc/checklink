<?php

if ($file = fopen("file.txt", "r")) {
    while(!feof($file)) {
        $line = fgets($file);
        $fuck = explode('|', $line);
        $url = ($fuck[0]);

        echo "<pre>";
        echo $fuck[2];
    	echo "</pre>";
    }
    fclose($file);
}