<?php 
session_start();
include('config.php');
@$session_test = $_SESSION['user_id'];
@$number = $_SESSION['number'];
if (!$session_test) {
    header("Location: login.php");
    exit();
}

else {
    $user_id = intval($_SESSION['user_id']);
    $number_login = intval($_SESSION['number']);
    $sql_query = @mysqli_query($conn, "SELECT * FROM user_info WHERE id='{$user_id}'");
    $member = @mysqli_fetch_array( $sql_query );
}

if ($member['role'] != 'premium') {
  echo('Sorry, this page is only for premium accounts!. <a href="input.php">Click here</a> to try Standard checker');
  exit();
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Multiple tracking link checker (Premium Account) | Tracking link checker</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Loading Font Awesome Icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    <!-- Loading Drunken Parrot UI -->
    <link href="css/drunken-parrot.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">
    


  <style type="text/css">
    .grey {
    color: #364347;
    }

    .custom-file-input::-webkit-file-upload-button {
    visibility: hidden;
    }
    .custom-file-input::before {
    content: 'Import File';
    display: inline-block;
    background: -webkit-linear-gradient(top, #f9f9f9, #e3e3e3);
    border: 1px solid #999;
    border-radius: 3px;
    padding: 5px 8px;
    outline: none;
    white-space: nowrap;
    -webkit-user-select: none;
    cursor: pointer;
    text-shadow: 1px 1px #fff;
    font-weight: 700;
    font-size: 10pt;
    }
    .custom-file-input:hover::before {
    border-color: black;
    }
    .custom-file-input:active::before {
    background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9);
    }
    body {
    background: #f8c145;
    }
    .tile-login {
    padding-bottom: 0px;
    }

    .navbar-inverse {
    padding-right: 50px;
    }
    .grey {
      color: #364347;
      }
    
    body {
      background: #f8c145;
    }
    .tile-login {
      padding-bottom: 0px;
    }

    .navbar-inverse {
      padding-right: 50px;
    }
    .panel-body {word-wrap: break-word;}
  #load{
      width:100%;
      height:100%;
      position:fixed;
      z-index:9999;
      background:url("loader.gif") no-repeat center center rgba(0,0,0,0.25)
  }
  </style>

<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'interactive') {
       document.getElementById('contents').style.visibility="hidden";
  } else if (state == 'complete') {
      setTimeout(function(){
         document.getElementById('interactive');
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('contents').style.visibility="visible";
      },1000);
  }
}
</script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->



  </head>
  <body>
<div id="load"></div>
<div class="row">
	<div class="container"> 
		<nav class="navbar navbar-inverse" role="navigation">
				
			<div class="navbar-header">
			<a class="navbar-brand" href="#">Tracking link checker</a>
			</div>
	
			<ul class="nav navbar-nav">
			<li class="active"><a href="#">Upgrade your account!</a></li>
			<li><a href="#">About Us</a></li>
      <li><a href="input.php">Standard Checker</a></li>
			</ul>

			<p class="navbar-text navbar-right"><a href="logout.php" class="navbar-link">Logout</a></p>
			<p class="navbar-text navbar-right"> | </a></p>
			<p class="navbar-text navbar-right">Hi, <a href="#" class="navbar-link"><?php echo $member['username']; ?></a></p>

		</nav>

		<div class="panel panel-default">
				<div class="panel-heading">
					<h4 class="panel-title">Multiple tracklink checker (Premium Account)</h4>
				</div>
				<div class="panel-body">

		            <form action="input2.php" method="post"  id="check_form" enctype="multipart/form-data">
		              
		              <div class="form-group">
		                <label for="username" class="grey">Import your file (.*txt)</label>
							<div class="form-group">
							  
									<input type="file" class="custom-file-input" name="filetxt" id="fileToUpload">
							   
							  </div>
		              </div>
				
			          <div class="form-group align-right">
		                  <button type="submit" name="submit" class="btn btn-block btn-orange btn-embossed">Submit</button>
		              </div>
		              <div class="form-group">
		              	<p><b>Notice:</b> Structure of the file is "Device|country|tranking link|package(android app) or id(ios app)". Package and id app is optinal.
		              	<br><b>- An Example: </b>iphone|us|http://i.tractas.com/index.php?offer_id=2650&aff_id=224|id1002597082<br><strong><a href="#">If you are newbie, please click here to watch tutorial!</a></strong></p>
		             	
		              </div>	              
		          </form>
				</div>
		</div>

<?php

include_once('simple_html_dom.php');

$i = 0;
$ketqua = 'null';

// POST START ///////////////
if (isset($_POST['submit']))
{
  ini_set('max_execution_time', 9999999);
  $original_string = 'nhdkxikfjhdisozxkdfkhijdmr7xozufij2b9dsb8zn90bx8x';
  $random_string = get_random_string($original_string, 10);

  // Nếu người dùng có chọn file để upload
  if (isset($_FILES['filetxt']))
  {
    // Nếu file upload không bị lỗi,
    // Tức là thuộc tính error > 0
    if ($_FILES['filetxt']['error'] > 0)
    {
      echo 'File Upload Bị Lỗi';
    }
    else {
      if ($_FILES['filetxt']['type'] !== 'text/plain') {
        echo('This file is not "TXT FILE"');
      }
      else {
        move_uploaded_file($_FILES['filetxt']['tmp_name'], './txtfile/'.$_FILES['filetxt']['name']); 
        
        // FUNCTION RANDOM ACCOUNT //
        function random_number_login()
          {
            GLOBAL $number_login;
            if ($number_login == 1) {
              $datafield = 'email=handestd@gmail.com&password=lvbadao1';
            }

            if ($number_login == 2) {
              $datafield = 'email=ngodung29693@gmail.com&password=ngovandung001';
            }

            if ($number_login == 3) {
              $datafield = 'email=contacts@cpatop1.com&password=ngovandung001';
            }

            if ($number_login == 4) {
              $datafield = 'email=ngovandung001@gmail.com&password=ngovandung001';
            }
            return $datafield;
          }
          // END FUNCTION

        //RUN FUNCTION
        $datafield = random_number_login();
      
        //========================== LOGIN START ================================//
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
        curl_setopt($ch, CURLOPT_URL, 'https://affilitest.com/user/login');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt ($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $datafield);
        $output = curl_exec($ch);
        curl_close($ch);
        //========================== LOGIN END ================================//

        //========================== GET RESULT ================================//
       
        //DEFINE FILE FUCK
        $fuck = array();

        //Interactive with file
        if ($file = fopen('./txtfile/'. $_FILES['filetxt']['name'], "r")) {
        // loop
        while(!feof($file)) {
        $line = fgets($file);
        @$fuck = explode('|', $line);
        @$device = $fuck[0];
        @$country = $fuck[1];
        @$url = $fuck[2];
        
        if (!is_null(@$fuck[3])) {
  
          @$previewlink = $fuck[3];
     
        }

        //the postfields
        $field2['url'] = $url;
        $field2['device'] = $device;
        $field2['country'] = $country;
        $datafield2 = http_build_query($field2);
        $datafield2 = strtolower($datafield2); 

        // extract result
        $ch2 = curl_init();
        curl_setopt($ch2, CURLOPT_COOKIEFILE, 'cookie.txt');
        curl_setopt($ch2, CURLOPT_COOKIEJAR, 'cookie.txt');
        curl_setopt($ch2, CURLOPT_URL, 'https://affilitest.com/validate');
        curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch2, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        //curl_setopt($ch2, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch2, CURLOPT_POST, 1);
        curl_setopt($ch2, CURLOPT_POSTFIELDS, $datafield2.'&device=android');

        $output = curl_exec($ch2);

        $array = json_decode($output, true);

      // define html
        $front_panel = '<div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">Result checking</h3></div><div class="panel-body">';
        $back_panel = '</div></div>';

        echo($front_panel);
        if ($array['data'] <> NULL) {
          $last = count($array['data']) - 1;
          $i = $i +1; 
          if (isset($previewlink)) {
            $string = $array['data'][$last];
            $string_find_1 = $previewlink; 
            $check_1 = strpos($string, $string_find_1);
            if ($check_1 <> false) {
              if ($check_1 <> 0) {
                $ketqua = 'true'; 
              }
            }
            else {
              $ketqua = 'false';
            }       
          }
          echo('<a href="output.php?url='.$url.'&device='.$device.'&country='.$country.'">Click to see details</a>');
          echo('<br><strong>- STT: '.$i.'</strong>');
          echo('<br><strong>- URL: </strong>'.$url.'');
          echo('<br><strong>- Device: </strong>'.$device.'');
          echo('<br><strong>- Country: </strong>'.$country.'');
          @$myfile = fopen($random_string . '.txt', "a") or die("Unable to open file!");
          
          if (!isset($previewlink)) {
            $txt = $i . '|'. $url . '|' . $device . '|' . $country . PHP_EOL;
          }
          else {
            $txt = $i . '|'. $url . '|' . $device . '|' . $country . '|' . $ketqua . PHP_EOL;
          }

          fwrite($myfile, $txt);
          fclose($myfile);
        }
        else {
      if ($array['error'] = "Device not in list") {
        echo('<b class="grey">Device not in list</b>');
      }
      else {
        echo('<b class="grey">Non of Data</b>');
      }
        }

        echo($back_panel);
        curl_close($ch2);
      }
fclose($file);
}               
}
}
}
else
{
echo 'Bạn chưa chọn file upload';
}

echo('<div class="panel panel-default"><div class="panel-body"><b><a href="'.$random_string.'.txt">View result (Txt file)</a></b></div></div>');

}

function get_random_string($valid_chars, $length)
{
    // start with an empty random string
    $random_string = "";

    // count the number of chars in the valid chars string so we know how many choices we have
    $num_valid_chars = strlen($valid_chars);

    // repeat the steps until we've created a string of the right length
    for ($i = 0; $i < $length; $i++)
    {
        // pick a random number from 1 up to the number of valid chars
        $random_pick = mt_rand(1, $num_valid_chars);

        // take the random character out of the string of valid chars
        // subtract 1 from $random_pick because strings are indexed starting at 0, and we started picking at 1
        $random_char = $valid_chars[$random_pick-1];

        // add the randomly-chosen char onto the end of our string so far
        $random_string .= $random_char;
    }

    // return our finished random string
    return $random_string;
}


?>
	</div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
  </body>
</html>



