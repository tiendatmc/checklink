<?php 
session_start();
include('config.php');
@$session_test = $_SESSION['user_id'];
@$number = $_SESSION['number'];

if (!$session_test or !$number) {
    header("Location: login.php");
    exit();
}

else {
    $user_id = intval($_SESSION['user_id']);
    $number_login = intval($_SESSION['number']);
    $sql_query = @mysqli_query($conn, "SELECT * FROM user_info WHERE id='{$user_id}'");
    $member = @mysqli_fetch_array( $sql_query );
}

 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Standard checker | Tracking link checker</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Loading Font Awesome Icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    <!-- Loading Drunken Parrot UI -->
    <link href="css/drunken-parrot.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">
    


  <style type="text/css">
    .grey {
      color: #f5f5f5;
      }
    
	.ahihi {
	    /* overflow: hidden; */
	    display: inline-grid;
	    /* padding: 0; */
	    /* margin: 0; */
	    overflow: hidden;
	    white-space: nowrap;
	}
body {
    background: url(https://i.ytimg.com/vi/isQ_Z7DRPX4/maxresdefault.jpg);
    /*background-repeat: no-repeat;*/
}
    }
    .tile-login {
      padding-bottom: 0px;
    }

    .navbar-inverse {
    	padding-right: 50px;
    }
    .panel-body {word-wrap: break-word;}
	#load{
	    width:100%;
	    height:100%;
	    position:fixed;
	    z-index:9999;
	    background:url("loader.gif") no-repeat center center rgba(0,0,0,0.25)
	}

  </style>

<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'interactive') {
       document.getElementById('contents').style.visibility="hidden";
  } else if (state == 'complete') {
      setTimeout(function(){
         document.getElementById('interactive');
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('contents').style.visibility="visible";
      },1000);
  }
}
</script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>
 <div id="load"></div>
<div class="row">
	<div class="container"> 
		<nav class="navbar navbar-inverse" role="navigation">
				
			<div class="navbar-header">
			<a class="navbar-brand" href="#">Tracking link checker</a>
			</div>
	
			<ul class="nav navbar-nav">
			<li class="active"><a href="#">Upgrade your account!</a></li>
			<li><a href="#">About Us</a></li>
			<li><a href="input2.php">Premium Checker</a></li>
			</ul>

			<p class="navbar-text navbar-right"><a href="logout.php" class="navbar-link">Logout</a></p>
			<p class="navbar-text navbar-right"> | </a></p>
			<p class="navbar-text navbar-right">Hi, <a href="#" class="navbar-link"><?php echo $member['username']; ?></a></p>

		</nav>

		<div class="panel panel-default" style="background: rgba(0,0,0,.5);">
				<div class="panel-heading">
					<h4 class="panel-title">One tracking link </h4>
				</div>
				<div class="panel-body">

		            <form action="input.php" method="post" id="check_form">
		              
		              <div class="form-group">
		                <label for="link" class="grey">Enter your affiliate/tracking link</label>
		                <input type="text"  class="form-control" id="link" name="link"  />
		              </div>

		              <div class="form-group">
		                <label for="previewlink" class="grey">Enter your App tracking (Optinal)</label>
		                <b class="grey"><br>Ex: com.my.heroesofutopia (Package name)<br> id911800950 (iOS App ID)</b>
		                <input type="text"  class="form-control" id="previewlink" name="previewlink"  />
		              </div>

					<div class="form-group">
		              <div class="row">
			              <div class="col-md-6" >
			              	<label for="device" class="grey" >Device</label>
			              	<select class="form-control" name="device" id="device">
				              <option value="android">Android</option>
				              <option value="iphone">iPhone</option>
				              <option value="ipad">iPad</option>
				              <option value="desktop">Desktop</option>
				              <option value="windowsPhone">Windows Phone</option>
				              <option value="blackberry">Blackberry</option>
							</select>
			              </div>
			              <div class="col-md-6" >
			              	<label for="device" class="grey" >Country</label>
								<select class="form-control" name="country" id="countryList">
									<option value="af">Afghanistan</option>
									<option value="ax">Åland Islands</option>
									<option value="al">Albania</option>
									<option value="dz">Algeria</option>
									<option value="ad">Andorra</option>
									<option value="ao">Angola</option>
									<option value="ai">Anguilla</option>
									<option value="ag">Antigua and Barbuda</option>
									<option value="ar">Argentina</option>
									<option value="am">Armenia</option>
									<option value="aw">Aruba</option>
									<option value="au">Australia</option>
									<option value="at">Austria</option>
									<option value="az">Azerbaijan</option>
									<option value="bs">Bahamas</option>
									<option value="bh">Bahrain</option>
									<option value="bd">Bangladesh</option>
									<option value="bb">Barbados</option>
									<option value="by">Belarus</option>
									<option value="be">Belgium</option>
									<option value="bz">Belize</option>
									<option value="bj">Benin</option>
									<option value="bm">Bermuda</option>
									<option value="bt">Bhutan</option>
									<option value="bo">Bolivia</option>
									<option value="bq">Bonaire, Sint Eustatius and Saba</option>
									<option value="ba">Bosnia and Herzegovina</option>
									<option value="bw">Botswana</option>
									<option value="br">Brazil</option>
									<option value="bn">Brunei Darussalam</option>
									<option value="bg">Bulgaria</option>
									<option value="bf">Burkina Faso</option>
									<option value="kh">Cambodia</option>
									<option value="cm">Cameroon</option>
									<option value="ca">Canada</option>
									<option value="cv">Cape Verde</option>
									<option value="ky">Cayman Islands</option>
									<option value="cf">Central African Republic</option>
									<option value="cl">Chile</option>
									<option value="cn">China</option>
									<option value="cc">Cocos (Keeling) Islands</option>
									<option value="co">Colombia</option>
									<option value="cr">Costa Rica</option>
									<option value="ci">Côte d'Ivoire</option>
									<option value="hr">Croatia</option>
									<option value="cw">Curaçao</option>
									<option value="cy">Cyprus</option>
									<option value="cz">Czech Republic</option>
									<option value="dk">Denmark</option>
									<option value="dj">Djibouti</option>
									<option value="dm">Dominica</option>
									<option value="do">Dominican Republic</option>
									<option value="ec">Ecuador</option>
									<option value="eg">Egypt</option>
									<option value="sv">El Salvador</option>
									<option value="gq">Equatorial Guinea</option>
									<option value="ee">Estonia</option>
									<option value="et">Ethiopia</option>
									<option value="fo">Faroe Islands</option>
									<option value="fj">Fiji</option>
									<option value="fi">Finland</option>
									<option value="fr">France</option>
									<option value="gf">French Guiana</option>
									<option value="pf">French Polynesia</option>
									<option value="gm">Gambia</option>
									<option value="ge">Georgia</option>
									<option value="de">Germany</option>
									<option value="gh">Ghana</option>
									<option value="gi">Gibraltar</option>
									<option value="gr">Greece</option>
									<option value="gl">Greenland</option>
									<option value="gd">Grenada</option>
									<option value="gp">Guadeloupe</option>
									<option value="gu">Guam</option>
									<option value="gt">Guatemala</option>
									<option value="gg">Guernsey</option>
									<option value="gn">Guinea</option>
									<option value="gy">Guyana</option>
									<option value="ht">Haiti</option>
									<option value="hn">Honduras</option>
									<option value="hk">Hong Kong</option>
									<option value="hu">Hungary</option>
									<option value="is">Iceland</option>
									<option value="in">India</option>
									<option value="id">Indonesia</option>
									<option value="ir">Iran</option>
									<option value="iq">Iraq</option>
									<option value="ie">Ireland</option>
									<option value="im">Isle of Man</option>
									<option value="il">Israel</option>
									<option value="it">Italy</option>
									<option value="jm">Jamaica</option>
									<option value="jp">Japan</option>
									<option value="je">Jersey</option>
									<option value="jo">Jordan</option>
									<option value="kz">Kazakhstan</option>
									<option value="ke">Kenya</option>
									<option value="kr">Korea - South</option>
									<option value="kw">Kuwait</option>
									<option value="kg">Kyrgyzstan</option>
									<option value="la">Laos</option>
									<option value="lv">Latvia</option>
									<option value="lb">Lebanon</option>
									<option value="lr">Liberia</option>
									<option value="ly">Libya</option>
									<option value="li">Liechtenstein</option>
									<option value="lt">Lithuania</option>
									<option value="lu">Luxembourg</option>
									<option value="mo">Macao</option>
									<option value="mk">Macedonia</option>
									<option value="mg">Madagascar</option>
									<option value="mw">Malawi</option>
									<option value="my">Malaysia</option>
									<option value="mv">Maldives</option>
									<option value="ml">Mali</option>
									<option value="mt">Malta</option>
									<option value="mh">Marshall Islands</option>
									<option value="mq">Martinique</option>
									<option value="mu">Mauritius</option>
									<option value="mx">Mexico</option>
									<option value="md">Moldova</option>
									<option value="mc">Monaco</option>
									<option value="mn">Mongolia</option>
									<option value="me">Montenegro</option>
									<option value="ms">Montserrat</option>
									<option value="ma">Morocco</option>
									<option value="mz">Mozambique</option>
									<option value="mm">Myanmar</option>
									<option value="nr">Nauru</option>
									<option value="np">Nepal</option>
									<option value="nl">Netherlands</option>
									<option value="nc">New Caledonia</option>
									<option value="nz">New Zealand</option>
									<option value="ni">Nicaragua</option>
									<option value="ne">Niger</option>
									<option value="ng">Nigeria</option>
									<option value="mp">Northern Mariana Islands</option>
									<option value="no">Norway</option>
									<option value="om">Oman</option>
									<option value="pk">Pakistan</option>
									<option value="ps">Palestinian Territory</option>
									<option value="pa">Panama</option>
									<option value="py">Paraguay</option>
									<option value="pe">Peru</option>
									<option value="ph">Philippines</option>
									<option value="pl">Poland</option>
									<option value="pt">Portugal</option>
									<option value="pr">Puerto Rico</option>
									<option value="qa">Qatar</option>
									<option value="re">Reunion</option>
									<option value="ro">Romania</option>
									<option value="ru">Russian Federation</option>
									<option value="rw">Rwanda</option>
									<option value="kn">Saint Kitts and Nevis</option>
									<option value="lc">Saint Lucia</option>
									<option value="mf">Saint Martin</option>
									<option value="vc">Saint Vincent and the Grenadines</option>
									<option value="ws">Samoa</option>
									<option value="sa">Saudi Arabia</option>
									<option value="sn">Senegal</option>
									<option value="rs">Serbia</option>
									<option value="sc">Seychelles</option>
									<option value="sl">Sierra Leone</option>
									<option value="sg">Singapore</option>
									<option value="sx">Sint Maarten (Dutch part)</option>
									<option value="sk">Slovakia</option>
									<option value="si">Slovenia</option>
									<option value="so">Somalia</option>
									<option value="za">South Africa</option>
									<option value="es">Spain</option>
									<option value="lk">Sri Lanka</option>
									<option value="sd">Sudan</option>
									<option value="sr">Suriname</option>
									<option value="sz">Swaziland</option>
									<option value="se">Sweden</option>
									<option value="ch">Switzerland</option>
									<option value="sy">Syria</option>
									<option value="tw">Taiwan</option>
									<option value="tj">Tajikistan</option>
									<option value="tz">Tanzania, United Republic of</option>
									<option value="th">Thailand</option>
									<option value="tl">Timor-Leste</option>
									<option value="tt">Trinidad and Tobago</option>
									<option value="tn">Tunisia</option>
									<option value="tr">Turkey</option>
									<option value="tm">Turkmenistan</option>
									<option value="tc">Turks and Caicos Islands</option>
									<option value="ug">Uganda</option>
									<option value="ua">Ukraine</option>
									<option value="ae">United Arab Emirates</option>
									<option value="uk">United Kingdom</option>
									<option value="us" selected="selected">United States</option>
									<option value="uy">Uruguay</option>
									<option value="uz">Uzbekistan</option>
									<option value="vu">Vanuatu</option>
									<option value="ve">Venezuela, Bolivarian Republic of</option>
									<option value="vn">Vietnam</option>
									<option value="vg">Virgin Islands, British</option>
									<option value="vi">Virgin Islands, U.S.</option>
									<option value="ye">Yemen</option>
									<option value="zm">Zambia</option>
									<option value="zw">Zimbabwe</option>
								</select>
			              </div>
		              </div>
					</div>
			          <div class="form-group align-right">
		                  <button type="submit" name="submit" class="load_button btn btn-block btn-orange btn-embossed" >Submit</button>
		              </div>	              
		          </form>
				</div>
		</div>
<?php


$ahihi = include_once('simple_html_dom.php');

function random_number_login()
{
	GLOBAL $number_login;
	if ($number_login == 1) {
		$datafield = 'email=handestd@gmail.com&password=lvbadao1';
	}

	if ($number_login == 2) {
		$datafield = 'email=ngodung29693@gmail.com&password=ngovandung001';
	}

	if ($number_login == 3) {
		$datafield = 'email=contacts@cpatop1.com&password=ngovandung001';
	}

	if ($number_login == 4) {
		$datafield = 'email=ngovandung001@gmail.com&password=ngovandung001';
	}
	return $datafield;
}

$datafield = random_number_login();

if (isset($_POST['submit'])) {
	if (!empty($_POST['link']) and !empty($_POST['device']) and !empty($_POST['country'])) {

		ini_set('max_execution_time', 9999999);
		$field2['url'] = $_POST['link'];
		$field2['device'] = $_POST['device'];
		$field2['country'] = $_POST['country'];
		@$previewlink = $_POST['previewlink'];

		//========================== LOGIN START ================================//
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
		curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
		curl_setopt($ch, CURLOPT_URL, 'https://affilitest.com/user/login');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt ($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $datafield);
		$output = curl_exec($ch);
		curl_close($ch);
		//========================== LOGIN END ================================//

		//========================== GET RESULT ================================//

		$datafield2 = http_build_query($field2);
		$datafield2 = strtolower($datafield2); 


		$ch2 = curl_init();
		curl_setopt($ch2, CURLOPT_COOKIEFILE, 'cookie.txt');
		curl_setopt($ch2, CURLOPT_COOKIEJAR, 'cookie.txt');
		curl_setopt($ch2, CURLOPT_URL, 'https://affilitest.com/validate');
		curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch2, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		//curl_setopt($ch2, CURLOPT_TIMEOUT, 60);
		curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ch2, CURLOPT_POST, 1);
		curl_setopt($ch2, CURLOPT_POSTFIELDS, $datafield2.'&device=android');

		$output = curl_exec($ch2);

		$array = json_decode($output, true);


		$front_panel = '<div class="panel panel-default" style="background: rgba(0,0,0,.5);"><div class="panel-heading"><h3 class="panel-title">Result checking</h3></div><div class="panel-body">';
		$back_panel = '</div></div>';

		echo($front_panel);

		if ($array['data'] <> NULL) {
		$last = count($array['data']) - 1;
			
			
			$string_find_1 = 'itunes.apple.com';
			$string_find_2 = 'details'; 

			$check_1 = strpos($array['data'][$last], $string_find_1);
			$check_2 = strpos($array['data'][$last], $string_find_2); 




			if ($check_1 == false) {
				if ($check_2 <> false) {
					if ($check_2 <> 0) {
						echo('<br><b><div class="alert alert-primary alert-dismissable">Last link redirect to Google Play Store:</div></b>');
						$str =	$array['data'][$last];
						$a = explode('id=', $str);
						include_once('simple_html_dom.php');
						$url_chplay = 'https://play.google.com/store/apps/details?id=' . $a[1];
						$html =  file_get_html($url_chplay);
						$viewstate = $html->find('img[class=cover-image]', 0);
						$url = $viewstate->src;
						$url = str_replace('//', '', $url);
										
						$cac = $html->find('div[class=id-app-title]', 0);
						echo '<div class="alert alert-info alert-dismissable"><b><img src="crown.png"/>App name: ' . $cac->plaintext . '</b></div>';
						echo('<br>');					
					}
				}
				else {
					echo('<br><b>Last link do not redirect to Any Store!</b>');
				}
			}
			else {
				if ($check_1 <> 0) {
					echo('<br><b><div class="alert alert-primary alert-dismissable">Last link redirect to AppStore.</div></b>');
					$str = $array['data'][$last];
					$a = explode('//', $str);
					$html =  file_get_html('https://'.$a[1]);
					$url_appstore = 'https://'.$a[1];
					$cac = $html->find('meta[itemprop=image]',0);
					$url = $cac->content;
					//<h1 itemprop="name">Trivia Crack Kingdoms</h1>
					$cac = $html->find('h1[itemprop=name]', 0);
					echo '<div class="alert alert-info alert-dismissable"><b><br><img src="crown.png"/>App name: ' . $cac->plaintext . '</b></div>';		
					echo('<div class="alert alert-info alert-dismissable"><br><img src="right-arrow.png"/><a href="https://www.affplus.com/?q='. $cac->plaintext .'"><b>See Infomation about this app</b></a></div>');
					echo('<br>');					

				}
			}
			echo('<br>');
			echo('<div class="alert alert-info alert-dismissable"><img src="map-location.png"/><b>Path:</b> ');
				for ($i=0; $i < count($array['data']); $i++) { 
					$chars=str_split($array['data'][$i]);
					$count=0;
					foreach($chars as &$char)
					{
					    if($char=='.')
					    {
					  $count++;
					    }
					}

					if ($count == 2) {
						
						$special_net_1 = strpos($array['data'][$i], 'offerslook.com');
						$special_net_2 = strpos($array['data'][$i], 'afftrack.com');
						$special_net_3 = strpos($array['data'][$i], 'go2cloud.org');
						$special_net_4 = strpos($array['data'][$i], 'hasoffers.com');
						$special_net_5 = strpos($array['data'][$i], 'go2affise.com');

						if (($special_net_1 <> false and $special_net_1 > 0) or ($special_net_2 <> false and $special_net_2 > 0) or ($special_net_3 <> false and $special_net_3 > 0) or ($special_net_4 <> false and $special_net_4 > 0) or ($special_net_5 <> false and $special_net_5 > 0)) {

							$fuck = explode('.', $array['data'][$i]);
							$fuck[0] = str_replace('http://', '', $fuck[0]);
							echo '<b>' . ($fuck[0]) . ' <img src="fast-forward.png"> ' . '</b>';
							
						}
						


						$fuck = explode('.', $array['data'][$i]);
						echo '<b>' . $fuck[1] . ' <img src="fast-forward.png"> ' . '</b>'; 
					}
					if ($count == 1) {
						$fuck = explode('.', $array['data'][$i]);
						$fuck[0] = str_replace('http://', '', $fuck[0]);
						echo '<b>' . ($fuck[0]) . ' <img src="fast-forward.png"> ' . '</b>';
					}
				}

				@$image_ios = strpos($url, 'mzstatic'); 

				if ($image_ios == false) {
					echo('<a href="'.@$url_chplay.'"><img src="https://'.@$url.'"></a>');
				}
				else {
					if ($image_ios <> 0) {
						echo('<a href="'.@$url_appstore.'"><img src="'.@$url.'"></a>');
					}
				}
				
				echo('</div><br>');

				echo('<b>Last link: </b>') . $array['data'][$last];

			if (!empty($_POST['previewlink'])) {

				$string = $array['data'][$last];

				$previewlink = $_POST['previewlink'];

				$string_find_1 = $previewlink; 

				$check_1 = strpos($string, $string_find_1);

				if ($check_1 <> false) {
						if ($check_1 <> 0) {
							echo('<br><b>Last link is the same previewlink</b>');
						}
					}
					else {
						echo('<br><b>Last link is not the same previewlink</b>');
					}				
			}


			echo('<br><b>Redirections:</b><br>');
			for ($i=0; $i < count($array['data']); $i++) { 
				echo '<b>' . ($i) . '</b>: ' . $array['data'][$i] . '<br>';
			}


		}
		else {
			echo('Non of Data');
		}

		echo($back_panel);

		curl_close($ch2);	
	}
}

?>

	</div>
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
  </body>
</html>








