<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
echo '<title>Success!</title>';
if (session_destroy()) 
    header('Location: login.php');
else
    echo "Error from system";
 

?>