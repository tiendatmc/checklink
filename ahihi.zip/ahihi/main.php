<?php 

//======================= ABOUT THIS CODE ==================// 
//=== AUTHOR: DINHTIENDAT ==================================//
//=== CONTACT WITH AUTHOR: https://m.facebook.com/tiendat.depzai ==//
//=== AUTHOR'S SITE: https://blog-sundragon.rhcloud.com ==//
//========================================================// 

//=========== DO NOT COPY, IF YOU DONT ASK ME ===========// 

$taikhoan = null;
$matkhau = null; 

$datafield = 'email=handestd@gmail.com&password=lvbadao1';


//========================== LOGIN START ================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
curl_setopt($ch, CURLOPT_URL, 'https://affilitest.com/user/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $datafield);
$output = curl_exec($ch);
curl_close($ch);
//========================== LOGIN END ================================//

//========================== GET RESULT ================================//

$fuck = array();

if ($file = fopen("file.txt", "r")) {
    while(!feof($file)) {
        $line = fgets($file);
       	@$fuck = explode('|', $line);
        @$url = $fuck[0];
        @$device = $fuck[1];
        @$country = $fuck[2];
		ini_set('max_execution_time', 300);

		$field2['url'] = $url;
		$field2['device'] = $device;
		$field2['country'] = $country;

		$datafield2 = http_build_query($field2);
		$ch2 = curl_init();
		curl_setopt($ch2, CURLOPT_COOKIEFILE, 'cookie.txt');
		curl_setopt($ch2, CURLOPT_COOKIEJAR, 'cookie.txt');
		curl_setopt($ch2, CURLOPT_URL, 'https://affilitest.com/validate');
		curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch2, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		//curl_setopt($ch2, CURLOPT_TIMEOUT, 60);
		curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ch2, CURLOPT_POST, 1);
		curl_setopt($ch2, CURLOPT_POSTFIELDS, $datafield2.'&device=android');

		$output = curl_exec($ch2);

		$array = json_decode($output, true);

		echo "<pre>";
		var_dump($array) ;
		echo "</pre>";

		curl_close($ch2);
    }
    fclose($file);
}





//========================== GET RESULT END ================================//

