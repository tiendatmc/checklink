
<?php 
date_default_timezone_set('Asia/Ho_Chi_Minh');

echo '<pre>';


$getdate = getdate();

$yday = $getdate['yday'];

echo($yday);



$end_day = @$mysql_day +  30; 

if ($end_day >= $yday) {
    echo('dcm het han cmnr');
}

 echo '</pre>';