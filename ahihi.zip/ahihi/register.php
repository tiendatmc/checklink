<?php 
ob_start();

@$session_test = $_SESSION['user_id'];
if ($session_test) {
  header('Location: input.php');
}


require_once __DIR__ . '/recapcha/src/autoload.php';
$phong = false; 
// Register API keys at https://www.google.com/recaptcha/admin
$siteKey = '6LdfMB4UAAAAAI7twGm4FLKooust9uJLX33tSdFU';
$secret = '6LdfMB4UAAAAANIM7ZmdcJiasd4uMGWOjho-cAun';

// reCAPTCHA supported 40+ languages listed here: https://developers.google.com/recaptcha/docs/language
$lang = 'en';

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Register</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Loading Font Awesome Icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    <!-- Loading Drunken Parrot UI -->
    <link href="css/drunken-parrot.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">
    


  <style type="text/css">
    .grey {
      color: #d6e1e5;
      }
    
    body {
      background: url(http://wowonder.me/themes/wowonder/img/backgrounds/background-1.jpg);
    }
    .tile-login {
      padding-bottom: 0px;
      background: rgba(221, 221, 221, 0.35); 
    }

  </style>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>
  <div class="modal fade" id="modal-success" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Announce</h4>
        </div>
        <div class="modal-body">
          <p>The account has been registered successfully.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-failure-capcha" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Announce</h4>
        </div>
        <div class="modal-body">
          <p>Invalid Capcha</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

    <div class="modal fade" id="modal-failure" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Announce</h4>
        </div>
        <div class="modal-body">
          <p>Account registered failed.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>


<div class="row">
  <div class="col-md-4 col-md-offset-4">
  <div style="padding: 10px;"></div>
    <div class="panel panel-default" style="background: none; border: none;">
      
          <div class="panel-body tile-login">
            
            <form action="register.php" method="post">
              
              <div class="form-group">
                <label for="username" class="grey">Username</label>
                <input type="text"  class="form-control" id="username" name="username"  />
              </div>

              <div class="form-group">
                <label for="username" class="grey">Email</label>
                <input type="text"  class="form-control" id="email" name="email"  />
              </div>

              <div class="form-group">
                <label for="password" class="grey">Password</label>
                <input type="password"  class="form-control" id="password" name="password"  />
              </div>

              <div class="form-group">
                <label for="password" class="grey">Re-Password</label>
                <input type="password"  class="form-control" id="re-password" name ="re-password" />
              </div>
              <div class="form-group">
                  <div class="g-recaptcha" data-sitekey="<?php echo $siteKey; ?>"></div>
                  <script type="text/javascript"
                          src="https://www.google.com/recaptcha/api.js?hl=<?php echo $lang; ?>">
                  </script>               
              </div>
              <div class="form-group">
                  <button type="submit" name="submit" class="btn btn-primary">Register</button>
              </div>
          </form>
        </div>
          <div class="panel-footer">Do you already have an account? <a href="login.php">Login here</a></div>
      </div>
    </div>
  </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>


<?php

include('config.php');

$success = '<script>$(document).ready(function(){$("#modal-success").modal();});</script>';
$failure = '<script>$(document).ready(function(){$("#modal-failure").modal();});</script>';
$failure_capcha = '<script>$(document).ready(function(){$("#modal-failure-capcha").modal();});</script>';

if (isset($_POST['submit'])) {
  if (!empty($_POST['username']) and !empty($_POST['password']) and !empty($_POST['re-password']) and !empty($_POST['email'])) {
    
if ($siteKey === '' || $secret === '') {
          echo('invaild key');
          exit();
      
}

elseif (isset($_POST['g-recaptcha-response'])) {
    $recaptcha = new \ReCaptcha\ReCaptcha($secret);
   
    $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

    if ($resp->isSuccess()) {
      
      $user = strip_tags(trim($_POST['username']));
      $user = str_replace(array("\r","\n"),array(" "," "),$user);
      $email = addslashes($_POST['email']);
      $password = addslashes($_POST['password']);

        $sql_user = "SELECT username FROM user_info WHERE username='$user'";
        $sql_email = "SELECT email FROM user_info WHERE email='$email'";

        $sql = "INSERT INTO user_info (username, password, email) VALUES ('{$user}', '{$password}', '{$email}')";

        if ($conn->query($sql) == True) {
          echo($success);
        }
        else {
          echo ($failure);
        }
        $conn->close();
    }
         
    else {
      echo($failure_capcha);
      exit();
    }
}

     
else {
    echo('vcl');
} 


  }
  else {
    echo "Chưa nhập đầy đủ thông tin";
  }
}
ob_end_flush(); 



