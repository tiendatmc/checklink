<!DOCTYPE HTML>
<?php include('header.php');
      include('paypal_config.php');
   

       ?>

         
           

       <div class="container">

       <div class="row">
         <div class="col-md-10 col-md-offset-10"></div>
      
            <form class="form" action="paypal_ec_redirect.php" method="POST">

              
                        
                        <table>
                        <tr><td>Package</td><td><input type="text" name="L_PAYMENTREQUEST_0_NAME0" value="standard 1 month"></input></td></tr>
                        <tr><td>Item ID: </td><td><input type="text" name="L_PAYMENTREQUEST_0_NUMBER0" value="1"></input></td></tr>
                        <tr><td>Description:</td><td><input type="text" name="L_PAYMENTREQUEST_0_DESC0" value="1"></input></td></tr>
                        <tr><td>Quantity:</td><td><input type="text" name="L_PAYMENTREQUEST_0_QTY0" value="1" readonly></input></td></tr>
                        <tr><td>Price:</td><td><input type="text" name="PAYMENTREQUEST_0_ITEMAMT" value="1" readonly></input></td></tr>
                      
                        <tr><td>Total Amount:</td><td><input type="text" name="PAYMENTREQUEST_0_AMT" value="1" readonly></input></td></tr>
                        <tr><td><input type="hidden" name="LOGOIMG" value=<?php echo('http://'.$_SERVER['HTTP_HOST'].preg_replace('/index.php/','img/logo.jpg',$_SERVER['SCRIPT_NAME'])); ?>></input></td></tr>
                        <tr><td>Currency Code:</td><td><select name="currencyCodeType">
            <option value="AUD">AUD</option>
            <option value="BRL">BRL</option>
            <option value="CAD">CAD</option>
            <option value="CZK">CZK</option>
            <option value="DKK">DKK</option>
            <option value="EUR">EUR</option>
            <option value="HKD">HKD</option>
            <option value="MYR">MYR</option>
            <option value="MXN">MXN</option>
            <option value="NOK">NOK</option>
            <option value="NZD">NZD</option>
            <option value="PHP">PHP</option>
            <option value="PLN">PLN</option>
            <option value="GBP">GBP</option>
            <option value="RUB">RUB</option>
            <option value="SGD">SGD</option>
            <option value="SEK">SEK</option>
            <option value="CHF">CHF</option>
            <option value="THB">THB</option>
            <option value="USD" selected>USD</option><br></td></tr>
                        <tr><td>Payment Type: </td><td><select>
                                                           <option value="Sale">Sale</option>
                                                           <option value="Authorization">Authorization</option>
                                                           <option value="Order">Order</option>
                                                         </select><br></td></tr>

                        <tr><td colspan="2"><br/><br/><div id="myContainer"></div></td></tr>
            <tr><td> -- OR -- </td></tr>
            <tr><td ><input type="Submit" alt="Proceed to Checkout" class="btn btn-primary btn-large" value="Proceed to Checkout" name="checkout"/></td></tr>
                        </table>
                  </div>
               </div>
            </form>
   </div>
     </div>
    </div>
   </div>
   <div class="span1">
   </div>
   <!--Script to dynamically choose a seller and buyer account to render on index page-->
   <script type="text/javascript">
      function getRandomNumberInRange(min, max) {
          return Math.floor(Math.random() * (max - min) + min);
      }


      var buyerCredentials = [{"email":"rakkiebuyer@gmail.com", "password":"12345678"}];
      var randomBuyer = getRandomNumberInRange(0,buyerCredentials.length);

      document.getElementById("buyer_email").value =buyerCredentials[randomBuyer].email;
      document.getElementById("buyer_password").value =buyerCredentials[randomBuyer].password;


   </script>

   <script type="text/javascript">
   window.paypalCheckoutReady = function () {
       paypal.checkout.setup('<?php echo($merchantID); ?>', {
           container: 'myContainer',
           environment: '<?php echo($env); ?>'
       });
   };
   </script>
   <script src="//www.paypalobjects.com/api/checkout.js" async></script>

<?php include('footer.php') ?>
