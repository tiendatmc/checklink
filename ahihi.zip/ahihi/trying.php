<?php

	ini_set('max_execution_time', 300);
	$datafield = 'email=handestd@gmail.com&password=lvbadao1';
	$url = 'http://tr.mobaloo.com/?offer_id=1106943&pub_id=5767';
	$device = 'android';
	$country = 'tw';

	$field2['url'] = $url;
	$field2['device']= $device;
	$field2['country'] = $country;

	$datafield2 = http_build_query($field2);
	$ch = curl_init();
	//curl_setopt($ch, CURLOPT_URL, 'https://affilitest.com');
	curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
	curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
	//curl_setopt($ch, CURLOPT_URL, 'https://affilitest.com/user/login');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
	//curl_setopt ($ch, CURLOPT_POST, 1);
	//curl_setopt($ch, CURLOPT_POSTFIELDS, $datafield);
	curl_setopt($ch, CURLOPT_URL, 'https://affilitest.com/validate');
	curl_setopt ($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datafield2.'&device=android');
	$output = curl_exec($ch);
	echo($output);
	curl_close($ch);
