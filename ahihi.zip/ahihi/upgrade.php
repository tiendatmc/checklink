<?php 
session_start();
include('config.php');
@$session_test = $_SESSION['user_id'];

if (!$session_test) {
    header("Location: login.php");
    exit();
}

else {
    $user_id = intval($_SESSION['user_id']);
    $sql_query = @mysqli_query($conn, "SELECT * FROM user_info WHERE id='{$user_id}'");
    $member = @mysqli_fetch_array( $sql_query );
}

 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Upgrade your account</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Loading Font Awesome Icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    <!-- Loading Drunken Parrot UI -->
    <link href="css/drunken-parrot.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">
    


  <style type="text/css">
    .grey {
      color: #364347;
      }
    
	.ahihi {
	    /* overflow: hidden; */
	    display: inline-grid;
	    /* padding: 0; */
	    /* margin: 0; */
	    overflow: hidden;
	    white-space: nowrap;
	}
  body {
      background: url(http://freedomreply.com/wp-content/uploads/2014/06/background-images-for-web-design-2.jpg);
      
  }
    .tile-login {
      padding-bottom: 0px;
    }

    .navbar-inverse {
    	padding-right: 50px;
    }
    .panel-body {word-wrap: break-word;}
	#load{
	    width:100%;
	    height:100%;
	    position:fixed;
	    z-index:9999;
	    background:url("loader.gif") no-repeat center center rgba(0,0,0,0.25)
	}

.tile-profile img {
    width: 150px;
}

.tile-profile {
    background-color: rgba(0,0,0,.5);
    border: 1px solid rgba(245, 245, 245, 0.22);
}

  </style>

<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'interactive') {
       document.getElementById('contents').style.visibility="hidden";
  } else if (state == 'complete') {
      setTimeout(function(){
         document.getElementById('interactive');
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('contents').style.visibility="visible";
      },1000);
  }
}
</script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>
 <div id="load"></div>
<div class="row">
	<div class="container"> 
		<nav class="navbar navbar-inverse" role="navigation">
				
			<div class="navbar-header">
			<a class="navbar-brand" href="#">Tracking link checker</a>
			</div>
	
			<ul class="nav navbar-nav">
			<li class="active"><a href="Upgrade.php">Upgrade your account!</a></li>
			<li><a href="#">About Us</a></li>
			<li><a href="input2.php">Premium Checker</a></li>
			</ul>

			<p class="navbar-text navbar-right"><a href="logout.php" class="navbar-link">Logout</a></p>
			<p class="navbar-text navbar-right"> | </a></p>
			<p class="navbar-text navbar-right">Hi, <a href="#" class="navbar-link"><?php echo $member['username']; ?></a></p>

		</nav>

		
          <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3">
              <div class="tile tile-profile" style="height: 500px;">
              <img src="image/vip2.png" alt="" style="">
              <h4>Standard</h4>
              <p>- Unlimited one link tracking</p>
              <p>- Best for individual affiliate or media buyer</p>
              <a href="Standard.php" class="btn btn-block btn-danger btn-embossed" style="margin-top: 80px;">Upgrade</a>
            </div>  
          </div>
          <div class="col-md-3">
              <div class="tile tile-profile" style="height: 500px;">
              <img src="image/photo.jpg" alt="">
              <h4>Premium</h4>
              <p>- Unlimited Multiple link tracking</p>
              <p>- Best for network</p>
              <a href="Premium.php" class="btn btn-block btn-danger btn-embossed" style="margin-top: 80px;">Upgrade</a>
            </div>  
          </div>
          <div class="col-md-3"></div>
        </div>






<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
  </body>
</html>
